@echo off
rem LinkedIn Company Scraper - updater. Double-click to update this folder to the latest version.
rem Downloads the newest build, checks it, then replaces the files here. Afterwards press
rem "Reload after update" in the scraper panel (or the reload arrow on chrome://extensions).
title LinkedIn Company Scraper - Update
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ErrorActionPreference = 'Stop';" ^
 "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;" ^
 "$dir = '%~dp0'.TrimEnd('\');" ^
 "$base = 'https://raw.githubusercontent.com/mmsrect/linkedin-company-scraper-dist/main';" ^
 "$self = 'Update Scraper.cmd';" ^
 "try {" ^
 "  $current = (Get-Content -Raw (Join-Path $dir 'manifest.json') | ConvertFrom-Json).version;" ^
 "  $latest = (Invoke-WebRequest -UseBasicParsing -Headers @{'Cache-Control'='no-cache'} ($base + '/version.txt')).Content.Trim();" ^
 "  Write-Host ('Installed: ' + $current + '   Latest: ' + $latest);" ^
 "  if ($current -eq $latest) { Write-Host 'Already up to date. Nothing to do.'; exit 0 }" ^
 "  $tmp = Join-Path $env:TEMP ('lcs-update-' + [guid]::NewGuid());" ^
 "  New-Item -ItemType Directory $tmp | Out-Null;" ^
 "  $zip = Join-Path $tmp 'latest.zip'; $out = Join-Path $tmp 'files';" ^
 "  Write-Host 'Downloading...';" ^
 "  Invoke-WebRequest -UseBasicParsing ($base + '/latest.zip') -OutFile $zip;" ^
 "  Expand-Archive $zip -DestinationPath $out -Force;" ^
 "  $newVer = (Get-Content -Raw (Join-Path $out 'manifest.json') | ConvertFrom-Json).version;" ^
 "  if ($newVer -ne $latest) { throw ('Downloaded build says ' + $newVer + ', expected ' + $latest) }" ^
 "  Write-Host 'Download checked. Replacing files...';" ^
 "  Get-ChildItem $dir -Force | Where-Object { $_.Name -ne $self } | Remove-Item -Recurse -Force;" ^
 "  Get-ChildItem $out -Force | Where-Object { $_.Name -ne $self } | Copy-Item -Destination $dir -Recurse -Force;" ^
 "  Remove-Item $tmp -Recurse -Force;" ^
 "  Write-Host '';" ^
 "  Write-Host ('Updated to ' + $latest + '. Now press Reload after update in the scraper panel,');" ^
 "  Write-Host 'or the reload arrow on chrome://extensions.';" ^
 "} catch {" ^
 "  Write-Host '';" ^
 "  Write-Host ('Update failed: ' + $_.Exception.Message) -ForegroundColor Red;" ^
 "  Write-Host 'Send a screenshot of this window to Mohsin.';" ^
 "}"
echo.
pause
